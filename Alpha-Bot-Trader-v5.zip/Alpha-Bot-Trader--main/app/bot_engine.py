"""
bot_engine.py — autonomous micro-trade engine.

Strategy (approved 2025-06):
  • Fixed-percentage exits replace ATR trailing stops so the bot cycles
    in/out of trades in minutes, not days:
      take-profit : +0.50 %  (BOT_TAKE_PROFIT_PCT)
      stop-loss   : -0.25 %  (BOT_STOP_LOSS_PCT)

  • Per-trade allocation: 15 % of the bot's allocated funds (BOT_PER_TRADE_FRACTION).

  • Simultaneous positions: up to 6 per bot (BOT_MAX_POSITIONS).
    After each entry the engine immediately scans for the next setup so all
    slots fill as fast as confirmed dips appear — not one per minute.

  • Autonomous bots (auto_select=True) scan the full market universe every
    cycle, skipping tickers already held, so capital is always diversified.

  • On exit (take-profit OR stop-loss) the freed slot is immediately offered
    to the next confirmed dip in the same cycle.

Every scan, entry and exit is logged to both the terminal and the per-user
ActivityLog table.
"""

from __future__ import annotations

import os
import logging
from datetime import datetime

from sqlalchemy.orm import Session

from app.database import Bot, BotPosition, Trade, User, ActivityLog, SessionLocal
from app.brokers import place_order, get_account_info, liquidate_position, BrokerError
from app.market_data import get_market_analysis
from app.markets_universe import MARKET_UNIVERSE
from app.credentials import resolve_credentials, has_credentials
from app.news_analysis import get_asset_sentiment
from app.pattern_analysis import Analysis

logger = logging.getLogger("alphabot.engine")

# ── Strategy parameters ───────────────────────────────────────────────
TAKE_PROFIT_PCT    = float(os.getenv("BOT_TAKE_PROFIT_PCT",    "0.005"))   # +0.50 %
STOP_LOSS_PCT      = float(os.getenv("BOT_STOP_LOSS_PCT",      "0.0025"))  # -0.25 %
PER_TRADE_FRACTION = float(os.getenv("BOT_PER_TRADE_FRACTION", "0.15"))    # 15 % per trade
MAX_POSITIONS      = int(os.getenv("BOT_MAX_POSITIONS",        "6"))        # 6 slots max

ENTRY_MIN_STRENGTH = float(os.getenv("BOT_ENTRY_MIN_STRENGTH", "0.30"))
CANDLE_LIMIT       = int(os.getenv("BOT_CANDLE_LIMIT",         "200"))
AUTO_SCAN_LIMIT    = int(os.getenv("BOT_AUTO_SCAN_LIMIT",      "20"))
NEWS_OVERLAY       = os.getenv("BOT_NEWS_OVERLAY", "1") in ("1", "true", "True", "yes")


# ── Realtime event emission ───────────────────────────────────────────
def _emit(event_type: str, data: dict, user_id: int | None = None) -> None:
    try:
        from app.realtime import bus
        bus.publish(event_type, data, user_id=user_id)
    except Exception as e:
        logger.debug("realtime emit failed (%s): %s", event_type, e)


def _emit_portfolio(user_id: int) -> None:
    _emit("portfolio_update", {"user_id": user_id}, user_id=user_id)


# ── Activity log ──────────────────────────────────────────────────────
def _log(db: Session, user_id: int, message: str, level: str = "INFO"):
    getattr(logger, level.lower(), logger.info)(message)
    try:
        db.add(ActivityLog(user_id=user_id, message=message, level=level))
        db.commit()
    except Exception as e:
        db.rollback()
        logger.warning("ActivityLog write failed: %s", e)


# ── Broker helpers ────────────────────────────────────────────────────
def _paper(owner: User) -> bool:
    return (owner.trading_mode or "paper") == "paper"


def _creds(owner: User, broker: str) -> dict:
    return resolve_credentials(owner, broker, _paper(owner))


def _asset_meta(broker: str, symbol: str) -> tuple[str, str]:
    cfg = MARKET_UNIVERSE.get((broker or "alpaca").lower(), {})
    for item in cfg.get("items", []):
        if item["symbol"].upper() == (symbol or "").upper():
            return item.get("name", symbol), cfg.get("asset_class", "Equity")
    return symbol, cfg.get("asset_class", "Equity")


def _get_buying_power(owner: User, broker: str) -> float | None:
    try:
        info = get_account_info(broker=broker, paper=_paper(owner), **_creds(owner, broker))
        if broker == "alpaca":
            return float(info.get("buying_power", 0.0))
        balances = info.get("balances", {})
        return float(balances.get("USDT", balances.get("USD", 0.0)))
    except Exception as e:
        logger.warning("Buying power lookup failed (%s): %s", broker, e)
        return None


# ── Order execution (real or paper-sim fallback) ──────────────────────
def _execute(owner: User, broker: str, side: str, symbol: str,
             qty: float = None, notional: float = None) -> dict:
    try:
        order = place_order(
            broker=broker, side=side, symbol=symbol, qty=qty, notional=notional,
            paper=_paper(owner), **_creds(owner, broker),
        )
        order["simulated"] = False
        return order
    except BrokerError as e:
        logger.warning("[SIM] %s %s %s simulated (broker said: %s)", side, symbol, broker, e)
        return {"order_id": f"SIM-{datetime.utcnow().timestamp():.0f}",
                "status": "simulated", "symbol": symbol, "side": side, "simulated": True}


def _liquidate(owner: User, broker: str, symbol: str) -> dict:
    has_keys = has_credentials(owner, (broker or "alpaca"), _paper(owner))
    try:
        order = liquidate_position(broker=broker, symbol=symbol,
                                   paper=_paper(owner), **_creds(owner, broker))
        order["simulated"] = False
        return order
    except BrokerError as e:
        if has_keys:
            logger.error("[LIQUIDATE] %s %s FAILED with live keys: %s", symbol, broker, e)
            raise
        logger.warning("[SIM] liquidate %s %s simulated (%s)", symbol, broker, e)
        return {"order_id": f"SIM-{datetime.utcnow().timestamp():.0f}",
                "status": "simulated", "symbol": symbol, "side": "sell", "simulated": True}


# ── Fixed-percentage risk arming ──────────────────────────────────────
def _arm_fixed_exits(pos: BotPosition, entry_price: float) -> None:
    """Set +0.50% take-profit and -0.25% stop-loss on a new BotPosition."""
    pos.stop_price        = round(entry_price * (1.0 - STOP_LOSS_PCT),   6)
    pos.take_profit_price = round(entry_price * (1.0 + TAKE_PROFIT_PCT), 6)


# ── Legacy single-position migration ─────────────────────────────────
def _migrate_legacy_position(db: Session, bot: Bot) -> None:
    """
    Bots created before multi-position support stored one open trade in the
    Bot row itself (in_position, shares_held, avg_entry_price …).  Move that
    into a BotPosition row transparently so the new engine can manage it.
    """
    if not bot.in_position or not bot.avg_entry_price or not (bot.shares_held or 0):
        return
    existing = db.query(BotPosition).filter(BotPosition.bot_id == bot.id).first()
    if existing:
        return
    entry = float(bot.avg_entry_price)
    qty   = float(bot.shares_held or 0)
    pos   = BotPosition(
        bot_id      = bot.id,
        ticker      = bot.ticker or "",
        broker      = bot.broker or "alpaca",
        qty         = qty,
        notional    = round(qty * entry, 2),
        entry_price = entry,
    )
    _arm_fixed_exits(pos, entry)
    db.add(pos)
    bot.stop_price        = None
    bot.take_profit_price = None
    bot.peak_price        = None
    db.commit()
    logger.info("[MIGRATE] Bot %s (%s): moved legacy %s position into BotPosition table.",
                bot.id, bot.name, bot.ticker)


# ── Analysis helpers ──────────────────────────────────────────────────
def _safe_analysis(bot: Bot, owner: User, symbol: str = None) -> Analysis | None:
    broker = bot.broker or owner.active_broker or "alpaca"
    sym = symbol or bot.ticker
    if not sym:
        return None
    try:
        return get_market_analysis(
            broker=broker, symbol=sym, timeframe=bot.timeframe or "1h",
            limit=CANDLE_LIMIT, paper=_paper(owner), **_creds(owner, broker),
        )
    except BrokerError as e:
        logger.warning("Analysis fetch failed for bot %s (%s): %s", bot.id, sym, e)
        return None


def _news_sanity(broker: str, symbol: str) -> dict:
    if not NEWS_OVERLAY:
        return {"label": "neutral", "score": 0.0, "veto": False,
                "note": "News overlay disabled.", "headlines": []}
    try:
        name, asset_class = _asset_meta(broker, symbol)
        return get_asset_sentiment(symbol, name, asset_class)
    except Exception as e:
        logger.debug("News sanity failed for %s: %s", symbol, e)
        return {"label": "neutral", "score": 0.0, "veto": False,
                "note": f"News check skipped ({e}).", "headlines": []}


def _record_quote(db: Session, broker: str, symbol: str, analysis: Analysis) -> None:
    if not symbol or analysis is None:
        return
    try:
        from app.market_store import upsert_quote
        candle_ts = analysis.candles[-1]["time"] if analysis.candles else None
        upsert_quote(db, broker, symbol, analysis.last_price,
                     signal_action=analysis.signal.action,
                     signal_strength=analysis.signal.strength,
                     candle_ts=candle_ts)
        _emit("market_quote", {
            "broker": (broker or "alpaca").lower(), "symbol": symbol.upper(),
            "price": analysis.last_price, "signal_action": analysis.signal.action,
            "signal_strength": analysis.signal.strength,
        })
    except Exception as e:
        logger.debug("quote record failed for %s:%s — %s", broker, symbol, e)


def _analysis_brief(a: Analysis) -> dict:
    return {"signal": a.signal.to_dict(), "indicators": a.indicators,
            "patterns": a.patterns, "last_price": a.last_price}


# ── Autonomous market selector ────────────────────────────────────────
def _pick_best_setup(db: Session, owner: User, bot: Bot,
                     skip_tickers: set | None = None) -> Analysis | None:
    """
    Scan the market universe for the strongest confirmed BUY setup.
    skip_tickers — uppercase symbols already held; never double-buy.
    """
    broker = bot.broker or owner.active_broker or "alpaca"
    cfg    = MARKET_UNIVERSE.get(broker.lower(), {})
    items  = cfg.get("items", [])
    if not items:
        return None

    skip   = {s.upper() for s in (skip_tickers or set())}
    scan_n = min(AUTO_SCAN_LIMIT, len(items))
    _log(db, owner.id,
         f"[AUTO-SCAN] '{bot.name}' scanning {scan_n}/{len(items)} {broker} markets…")

    candidates = []
    for item in items[:scan_n]:
        sym = item["symbol"]
        if sym.upper() in skip:
            continue
        analysis = _safe_analysis(bot, owner, symbol=sym)
        if analysis is None:
            continue
        sig = analysis.signal
        if sig.action == "BUY" and sig.strength >= ENTRY_MIN_STRENGTH:
            candidates.append((sig.strength, analysis))

    if not candidates:
        _log(db, owner.id,
             f"[AUTO-SCAN] No confirmed dip found (strength >= {ENTRY_MIN_STRENGTH}).")
        return None

    candidates.sort(key=lambda x: x[0], reverse=True)

    for strength, analysis in candidates:
        verdict = _news_sanity(broker, analysis.symbol)
        if verdict.get("veto"):
            _log(db, owner.id,
                 f"[AUTO-SCAN] {analysis.symbol} vetoed by news sanity ({verdict.get('note')})",
                 "WARNING")
            continue
        _log(db, owner.id,
             f"[AUTO-SCAN] Selected {analysis.symbol} strength={strength:.2f} "
             f"news={verdict.get('label')}: {analysis.signal.headline}")
        return analysis

    _log(db, owner.id, "[AUTO-SCAN] All setups vetoed by news layer.", "WARNING")
    return None


# ── Multi-position close ──────────────────────────────────────────────
def _close_bot_position(db: Session, owner: User, bot: Bot,
                         pos: BotPosition, price: float, reason: str) -> dict:
    """Close one BotPosition slot and record the trade."""
    qty      = pos.qty or 0
    ticker   = pos.ticker
    order    = _liquidate(owner, pos.broker or bot.broker or "alpaca", ticker)
    gain     = (price - pos.entry_price) * qty
    notional = round(qty * price, 6)

    bot.realized_pnl = (bot.realized_pnl or 0.0) + gain
    bot.trade_count  = (bot.trade_count  or 0)   + 1

    db.add(Trade(
        owner_id=owner.id, bot_id=bot.id, bot_uuid=bot.uuid,
        ticker=ticker, side="sell", qty=qty, notional=notional, price=price,
        broker=pos.broker or bot.broker, mode=owner.trading_mode,
        broker_order_id=order["order_id"], status=order["status"],
    ))
    _log(db, owner.id,
         f"[CLOSE] SELL {qty:.6f} {ticker} @ {price:.4f} ({reason}) "
         f"P&L: {gain:+.4f} | entry {pos.entry_price:.4f}",
         "WARNING" if gain < 0 else "INFO")

    db.delete(pos)

    remaining = db.query(BotPosition).filter(
        BotPosition.bot_id == bot.id, BotPosition.id != pos.id
    ).count()
    bot.in_position = remaining > 0
    if bot.auto_select and remaining == 0:
        bot.ticker = None

    db.commit()
    _emit("trade", {
        "bot_id": bot.id, "bot_uuid": bot.uuid, "bot_name": bot.name,
        "ticker": ticker, "side": "sell", "qty": round(qty, 8),
        "notional": notional, "price": price,
        "realized_pnl": round(gain, 4), "reason": reason,
    }, user_id=owner.id)
    _emit_portfolio(owner.id)
    return {"order": order, "realized_gain": round(gain, 4), "ticker": ticker}


# ── Multi-position open ───────────────────────────────────────────────
def _open_bot_position(db: Session, owner: User, bot: Bot,
                        analysis: Analysis, notional: float) -> dict | None:
    """Fund one new BotPosition slot. Caller must guard MAX_POSITIONS."""
    symbol = analysis.symbol or bot.ticker
    broker = bot.broker or owner.active_broker or "alpaca"
    price  = analysis.last_price

    if not price or price <= 0:
        _log(db, owner.id, f"[ENTRY] Skipped {symbol} — price unavailable.")
        return None
    if notional < 1.0:
        _log(db, owner.id, f"[ENTRY] Skipped {symbol} — notional ${notional:.2f} too small.")
        return None

    verdict = _news_sanity(broker, symbol)
    if verdict.get("veto"):
        _log(db, owner.id,
             f"[NEWS-VETO] {symbol}: news sanity blocked entry ({verdict.get('note')}).",
             "WARNING")
        return None

    order = _execute(owner, broker, "buy", symbol, notional=notional)
    qty   = round(notional / price, 8)

    pos = BotPosition(
        bot_id=bot.id, ticker=symbol.upper(), broker=broker,
        qty=qty, notional=round(notional, 2), entry_price=price,
        broker_order_id=order.get("order_id"),
    )
    _arm_fixed_exits(pos, price)
    db.add(pos)

    bot.in_position    = True
    bot.trade_count    = (bot.trade_count or 0) + 1
    bot.first_buy_done = True
    if not bot.auto_select:
        bot.ticker = symbol.upper()

    db.add(Trade(
        owner_id=owner.id, bot_id=bot.id, bot_uuid=bot.uuid,
        ticker=symbol.upper(), side="buy", qty=qty,
        notional=round(notional, 2), price=price, broker=broker,
        mode=owner.trading_mode, broker_order_id=order.get("order_id"),
        status=order.get("status", "submitted"),
    ))
    _log(db, owner.id,
         f"[ENTRY] BUY ${notional:.2f} ({qty:.6f}) {symbol} @ {price:.4f} "
         f"| stop {pos.stop_price:.4f} (+{STOP_LOSS_PCT*100:.2f}%) "
         f"| target {pos.take_profit_price:.4f} (+{TAKE_PROFIT_PCT*100:.2f}%)")
    db.commit()
    _emit("trade", {
        "bot_id": bot.id, "bot_uuid": bot.uuid, "bot_name": bot.name,
        "ticker": symbol, "side": "buy", "qty": qty, "notional": notional,
        "price": price, "realized_pnl": None, "reason": analysis.signal.headline,
    }, user_id=owner.id)
    _emit_portfolio(owner.id)
    return {
        "action": "BUY", "ticker": symbol, "notional": notional, "qty": qty,
        "stop_price": pos.stop_price, "take_profit_price": pos.take_profit_price,
        "order": order,
    }


# ── Price resolver for manual exits ──────────────────────────────────
def _resolve_exit_price(db: Session, bot: Bot, owner: User,
                         ticker: str = None) -> float:
    sym    = ticker or bot.ticker or ""
    broker = bot.broker or owner.active_broker or "alpaca"
    try:
        from app.market_store import get_quote
        q = get_quote(db, broker, sym)
        if q and q.price:
            return float(q.price)
    except Exception:
        pass
    a = _safe_analysis(bot, owner, symbol=sym)
    if a and a.last_price:
        return float(a.last_price)
    return float(bot.avg_entry_price or 0.0)


# ── Public API: single bot cycle ──────────────────────────────────────
def run_cycle(bot_id: int) -> dict:
    """
    One full micro-trade cycle for a single bot:

    1. EXIT SCAN  — check every open BotPosition; close immediately on
                    +0.50% (take-profit) or -0.25% (stop-loss).
    2. ENTRY SCAN — while open slots remain (< MAX_POSITIONS) and per-trade
                    budget is funded, scan for new BUY setups and fill slots.
                    Autonomous bots scan the whole universe; ticker-locked bots
                    only look at their fixed symbol.

    Both scans run in the SAME 60-second tick so the bot never sits idle
    between a close and the next entry opportunity.
    """
    db = SessionLocal()
    try:
        bot = db.query(Bot).filter(Bot.id == bot_id).first()
        if not bot:
            return {"action": "ERROR", "reason": "Bot not found."}
        if not bot.running:
            return {"action": "SKIPPED", "reason": "Bot is paused."}

        owner  = bot.owner
        broker = bot.broker or owner.active_broker or "alpaca"
        actions: list[dict] = []

        # Migrate any pre-existing legacy single-position.
        _migrate_legacy_position(db, bot)

        # ── EXIT SCAN ─────────────────────────────────────────────────
        for pos in db.query(BotPosition).filter(BotPosition.bot_id == bot.id).all():
            analysis = _safe_analysis(bot, owner, symbol=pos.ticker)
            if analysis is None:
                continue
            price = analysis.last_price
            if not price:
                continue

            bot.last_analysis_at = datetime.utcnow()
            bot.last_signal      = analysis.signal.action
            _record_quote(db, broker, pos.ticker, analysis)

            pct = (price - pos.entry_price) / pos.entry_price

            if price >= pos.take_profit_price:
                r = _close_bot_position(
                    db, owner, bot, pos, price,
                    f"take-profit {pct*100:+.3f}% (target +{TAKE_PROFIT_PCT*100:.2f}%)")
                actions.append({**r, "action": "SELL_TP"})

            elif price <= pos.stop_price:
                r = _close_bot_position(
                    db, owner, bot, pos, price,
                    f"stop-loss {pct*100:+.3f}% (limit -{STOP_LOSS_PCT*100:.2f}%)")
                actions.append({**r, "action": "SELL_SL"})

            else:
                _log(db, owner.id,
                     f"[HOLD] {pos.ticker} @ {price:.4f} | {pct*100:+.3f}% | "
                     f"stop {pos.stop_price:.4f} | target {pos.take_profit_price:.4f}")

        # ── ENTRY SCAN ────────────────────────────────────────────────
        open_positions = db.query(BotPosition).filter(BotPosition.bot_id == bot.id).all()
        n_open       = len(open_positions)
        already_held = {p.ticker.upper() for p in open_positions}
        total_funds  = float(bot.funds_allocated or 0.0)
        per_trade    = round(total_funds * PER_TRADE_FRACTION, 2)
        slots_free   = MAX_POSITIONS - n_open

        if slots_free > 0 and per_trade >= 1.0:
            bp = _get_buying_power(owner, broker)

            if bot.auto_select:
                for _ in range(slots_free):
                    trade_notional = min(per_trade, bp) if bp is not None else per_trade
                    if trade_notional < 1.0:
                        break
                    best = _pick_best_setup(db, owner, bot, skip_tickers=already_held)
                    if best is None:
                        break
                    result = _open_bot_position(db, owner, bot, best, trade_notional)
                    if result:
                        actions.append(result)
                        already_held.add(best.symbol.upper())
                        if bp is not None:
                            bp = max(0.0, bp - trade_notional)
            else:
                if bot.ticker and bot.ticker.upper() not in already_held:
                    trade_notional = min(per_trade, bp) if bp is not None else per_trade
                    if trade_notional >= 1.0:
                        analysis = _safe_analysis(bot, owner)
                        if analysis is None:
                            bot.last_pattern_summary = (
                                "Market data unavailable — check broker keys.")
                            db.commit()
                        else:
                            _record_quote(db, broker, bot.ticker, analysis)
                            bot.last_analysis_at    = datetime.utcnow()
                            bot.last_signal         = analysis.signal.action
                            bot.last_pattern_summary = (
                                f"{analysis.signal.bias.title()} | "
                                f"{analysis.signal.headline} "
                                f"(strength {analysis.signal.strength:.2f})")
                            if (analysis.signal.action == "BUY" and
                                    analysis.signal.strength >= ENTRY_MIN_STRENGTH):
                                result = _open_bot_position(
                                    db, owner, bot, analysis, trade_notional)
                                if result:
                                    actions.append(result)
                            else:
                                _log(db, owner.id,
                                     f"[WAIT] {bot.ticker} — no confirmed dip "
                                     f"(signal {analysis.signal.action} "
                                     f"strength {analysis.signal.strength:.2f}).")

        # ── Sync aggregate fields ──────────────────────────────────────
        remaining        = db.query(BotPosition).filter(BotPosition.bot_id == bot.id).count()
        bot.in_position  = remaining > 0
        if remaining:
            bot.last_pattern_summary = (
                f"Holding {remaining} position(s) — monitoring ±{TAKE_PROFIT_PCT*100:.2f}%/"
                f"-{STOP_LOSS_PCT*100:.2f}% exits.")
        db.commit()

        return {"action": "MULTI", "open_positions": remaining, "actions": actions}
    finally:
        db.close()


# ── Public API: liquidate all positions for a bot ─────────────────────
def liquidate_bot(bot_id: int, reason: str = "manual sell") -> dict:
    """Sell all BotPosition rows for a bot immediately."""
    db = SessionLocal()
    try:
        bot = db.query(Bot).filter(Bot.id == bot_id).first()
        if not bot:
            return {"action": "ERROR", "reason": "Bot not found."}
        owner = bot.owner
        _migrate_legacy_position(db, bot)

        positions = db.query(BotPosition).filter(BotPosition.bot_id == bot.id).all()
        if not positions:
            return {"action": "FLAT", "reason": "Bot holds no open positions."}

        closed = []
        for pos in positions:
            price = _resolve_exit_price(db, bot, owner, ticker=pos.ticker)
            r     = _close_bot_position(db, owner, bot, pos, price, reason=reason)
            closed.append(r)

        return {"action": "SELL", "reason": reason, "closed": closed}
    finally:
        db.close()


# ── Public API: scheduler entry point ────────────────────────────────
def run_all_active_bots() -> dict:
    """Scan + act on every running bot. Called by the background scheduler."""
    summary = {"scanned": 0, "actions": []}
    db = SessionLocal()
    try:
        bot_ids = [b.id for b in db.query(Bot.id).filter(Bot.running == True).all()]  # noqa: E712
    finally:
        db.close()

    logger.info("[ENGINE] Scanning %d active bot(s)", len(bot_ids))
    for bot_id in bot_ids:
        summary["scanned"] += 1
        try:
            res = run_cycle(bot_id)
            for a in res.get("actions", []):
                if a.get("action") not in (None, "HOLD", "SKIPPED", "WAIT", "ERROR"):
                    summary["actions"].append({"bot_id": bot_id, "action": a.get("action")})
        except Exception as e:
            logger.error("Cycle failed for bot %s: %s", bot_id, e)
    return summary
